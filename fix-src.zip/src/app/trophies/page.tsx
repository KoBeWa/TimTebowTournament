import { supabase } from "@/lib/supabase";
import { getSeasonSummaries } from "@/lib/queries";
import Link from "next/link";

async function getRecords() {
  // Highest/lowest weekly scores from matchups (both sides)
  const { data: matchups } = await supabase.from("weekly_matchups").select("season_year, week, manager_a, score_a, manager_b, score_b");

  const allScores = (matchups ?? []).flatMap((m) => [
    { season: m.season_year, week: m.week, manager_id: m.manager_a, points: Number(m.score_a) },
    { season: m.season_year, week: m.week, manager_id: m.manager_b, points: Number(m.score_b) },
  ]);

  const highWeek = [...allScores].sort((a, b) => b.points - a.points).slice(0, 10);
  const lowWeek = [...allScores].sort((a, b) => a.points - b.points).slice(0, 10);

  const { data: bestRecord } = await supabase
    .from("season_results").select("season_year, manager_id, wins, losses, ties, points_for")
    .order("wins", { ascending: false }).order("points_for", { ascending: false }).limit(10);

  const { data: mostPoints } = await supabase
    .from("season_results").select("season_year, manager_id, points_for")
    .order("points_for", { ascending: false }).limit(10);

  return { highWeek, lowWeek, bestRecord: bestRecord ?? [], mostPoints: mostPoints ?? [] };
}

async function getCareerLeaderboard() {
  const { data } = await supabase.from("season_results").select("manager_id, wins, losses, ties, points_for, points_against");
  const career: Record<string, { wins: number; losses: number; ties: number; pf: number; pa: number; seasons: number }> = {};
  for (const r of data ?? []) {
    if (!career[r.manager_id]) career[r.manager_id] = { wins: 0, losses: 0, ties: 0, pf: 0, pa: 0, seasons: 0 };
    career[r.manager_id].wins += r.wins || 0;
    career[r.manager_id].losses += r.losses || 0;
    career[r.manager_id].ties += r.ties || 0;
    career[r.manager_id].pf += Number(r.points_for) || 0;
    career[r.manager_id].pa += Number(r.points_against) || 0;
    career[r.manager_id].seasons += 1;
  }
  return Object.entries(career)
    .map(([id, s]) => ({ manager_id: id, ...s, winPct: s.wins / (s.wins + s.losses + s.ties) }))
    .sort((a, b) => b.wins - a.wins);
}

export default async function TrophyRoomPage() {
  const [seasons, records, leaderboard] = await Promise.all([getSeasonSummaries(), getRecords(), getCareerLeaderboard()]);

  const champCounts: Record<string, number> = {};
  for (const s of seasons) { champCounts[s.champion] = (champCounts[s.champion] || 0) + 1; }
  const champRanking = Object.entries(champCounts).sort((a, b) => b[1] - a[1]);

  return (
    <div className="space-y-12">
      <div>
        <h1 className="page-header gold-gradient">Trophy Room</h1>
        <p className="text-text-secondary mt-2">Records, Achievements und der ewige Ruhm</p>
      </div>

      {/* Championships */}
      <section>
        <h2 className="section-header text-text-primary mb-6">Championships</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {champRanking.map(([name, count], i) => (
            <Link key={name} href={`/manager/${name}`} className={`card p-6 text-center ${i === 0 ? "border-gold/30" : ""}`}>
              <div className={`text-4xl ${i === 0 ? "gold-gradient" : "text-text-primary"}`} style={{ fontFamily: '"Bebas Neue", Impact, sans-serif' }}>{count}</div>
              <div className="stat-label mt-1">{count === 1 ? "Title" : "Titles"}</div>
              <div className="text-text-primary mt-2 font-medium">{name}</div>
            </Link>
          ))}
        </div>
        <div className="mt-6 flex flex-wrap gap-2">
          {seasons.map((s) => (
            <Link key={s.year} href={`/history/${s.year}`} className="badge-gold">{s.year}: {s.champion}</Link>
          ))}
        </div>
      </section>

      {/* Career Leaderboard */}
      <section>
        <h2 className="section-header text-text-primary mb-6">Career Leaderboard</h2>
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-text-muted text-left">
                <th className="p-4">#</th><th className="p-4">Manager</th><th className="p-4 text-center">Record</th>
                <th className="p-4 text-right">Win %</th><th className="p-4 text-right">Total PF</th>
                <th className="p-4 text-right hidden sm:table-cell">Avg PF/Season</th>
              </tr>
            </thead>
            <tbody>
              {leaderboard.map((m, i) => (
                <tr key={m.manager_id} className="border-b border-border/50 hover:bg-bg-card-hover transition-colors">
                  <td className="p-4 text-text-muted">{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : i + 1}</td>
                  <td className="p-4"><Link href={`/manager/${m.manager_id}`} className="font-medium text-text-primary hover:text-gold transition-colors">{m.manager_id}</Link></td>
                  <td className="p-4 text-center font-mono"><span className="win">{m.wins}</span>-<span className="loss">{m.losses}</span>{m.ties > 0 && <>-<span className="tie">{m.ties}</span></>}</td>
                  <td className="p-4 text-right font-mono">{(m.winPct * 100).toFixed(1)}%</td>
                  <td className="p-4 text-right font-mono">{m.pf.toFixed(1)}</td>
                  <td className="p-4 text-right font-mono text-text-secondary hidden sm:table-cell">{(m.pf / m.seasons).toFixed(1)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Records */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {[
          { title: "Highest Weekly Score", data: records.highWeek, cols: ["manager_id", "points", "season", "week"] },
          { title: "Lowest Weekly Score", data: records.lowWeek, cols: ["manager_id", "points", "season", "week"] },
        ].map((rec) => (
          <div key={rec.title}>
            <h3 className="text-2xl tracking-wide text-text-primary mb-3" style={{ fontFamily: '"Bebas Neue", Impact, sans-serif' }}>{rec.title}</h3>
            <div className="card overflow-hidden">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-border text-text-muted text-left"><th className="p-3 w-10">#</th><th className="p-3">Manager</th><th className="p-3 text-right">Points</th><th className="p-3 text-right">Season</th><th className="p-3 text-right">Wk</th></tr></thead>
                <tbody>
                  {rec.data.map((r, i) => (
                    <tr key={i} className="border-b border-border/50 hover:bg-bg-card-hover transition-colors">
                      <td className="p-3 text-text-muted">{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : i + 1}</td>
                      <td className="p-3 text-text-primary">{r.manager_id}</td>
                      <td className="p-3 text-right font-mono">{r.points.toFixed(1)}</td>
                      <td className="p-3 text-right text-text-muted">{r.season}</td>
                      <td className="p-3 text-right text-text-muted">{r.week}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}
        {[
          { title: "Best Season Record", data: records.bestRecord },
          { title: "Most Points in a Season", data: records.mostPoints },
        ].map((rec) => (
          <div key={rec.title}>
            <h3 className="text-2xl tracking-wide text-text-primary mb-3" style={{ fontFamily: '"Bebas Neue", Impact, sans-serif' }}>{rec.title}</h3>
            <div className="card overflow-hidden">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-border text-text-muted text-left"><th className="p-3 w-10">#</th><th className="p-3">Manager</th><th className="p-3 text-right">Value</th><th className="p-3 text-right">Season</th></tr></thead>
                <tbody>
                  {rec.data.map((r: Record<string, unknown>, i: number) => (
                    <tr key={i} className="border-b border-border/50 hover:bg-bg-card-hover transition-colors">
                      <td className="p-3 text-text-muted">{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : i + 1}</td>
                      <td className="p-3 text-text-primary">{String(r.manager_id)}</td>
                      <td className="p-3 text-right font-mono">
                        {r.wins != null ? `${r.wins}-${r.losses}${Number(r.ties) > 0 ? `-${r.ties}` : ""}` : Number(r.points_for).toFixed(1)}
                      </td>
                      <td className="p-3 text-right text-text-muted">{String(r.season_year)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}
